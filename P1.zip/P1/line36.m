% Models of 34 kinds of different mycelial length and decomposition rate
% x = extension(mm)
% y = decomposition rate(%)
% Duration 122 days
%% temperature = 10 C degree
%for i=1:34
%eval(['x',num2str(i),'=[0,exrate(',num2str(i),',1)];'])
%eval(['y',num2str(i),'=[0,derate(',num2str(i),',1)];'])
%end
%for i=1:34
%   hold on
%eval(['plot(x',num2str(i),',y',num2str(i),');'])
%    end
%hold off
%title('Temperature = 10℃')
%xlabel('Hyphal extension rate (mm/day)','Fontsize',10)
%ylabel('Decomposition rate (%)','Fontsize',10)
%% temperature = 16 C degree
%for i=1:34
%eval(['x',num2str(i),'=[0,exrate(',num2str(i),',2)];'])
%eval(['y',num2str(i),'=[0,derate(',num2str(i),',2)];'])
%end
%for i=1:34
%    hold on
%eval(['plot(x',num2str(i),',y',num2str(i),');'])
%    end
%hold off
%title('Temperature = 16℃')
%xlabel('Hyphal extension rate (mm/day)','Fontsize',10)
%ylabel('Decomposition rate (%)','Fontsize',10)
%% temperature = 22 C degree
for i=1:34
eval(['x',num2str(i),'=[0,exrate(',num2str(i),',3)];'])
eval(['y',num2str(i),'=[0,derate(',num2str(i),',3)];'])
end
for i=1:34
    hold on
eval(['plot(x',num2str(i),',y',num2str(i),');'])
    end
hold off
title('Temperature = 22℃')
xlabel('Hyphal extension rate (mm/day)','Fontsize',10)
ylabel('Decomposition rate (%)','Fontsize',10)