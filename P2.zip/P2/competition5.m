clear,clc
h=0.1;%所取时间点间隔
ts=[0:h:25];%时间区间
x0=[10,10];%初始条件
opt=odeset('reltol',1e-6,'abstol',1e-9);
[t,x]=ode45(@fun12,ts,x0,opt);
figure
plot(t,x(:,1),'r',t,x(:,2),'b','LineWidth',2),grid;
%xlabel('Time (days)')
%ylabel('Area of the colony (mm^2)')
legend('Phellinus','Schizophyllum')
set(gcf,'color',[1 1 1])
figure
plot(x(:,1),x(:,2),'LineWidth',2),grid %作相轨线