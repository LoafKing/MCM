clear,clc
h=0.1;
ts=[0:h:150];
x0=[10,10];
opt=odeset('reltol',1e-6,'abstol',1e-9);
[t,x]=ode45(@fun10,ts,x0,opt);
figure
plot(t,x(:,1),'r',t,x(:,2),'b','LineWidth',2),grid;
xlabel('Time (days)')
ylabel('Area of the colony (mm^2)')
legend('Phlebia','Hyphoderma')
set(gcf,'color',[1 1 1])
figure
plot(x(:,1),x(:,2),'LineWidth',2),grid 