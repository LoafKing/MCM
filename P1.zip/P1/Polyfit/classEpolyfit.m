plot(p2final(:,1),p2final(:,2),'.')
[p,s]=polyfit(p2final(:,1),p2final(:,2),9);
[y,delta]=polyconf(p,p2final(:,1),s);
polytool(p2final(:,1),p2final(:,2),9)
y=polyval(p,p2final(:,1));
a=p2final(:,1);
b=p2final(:,2);