function  y=trans(x)
       a =      -18.72;  
       b =    -0.07217; 
       c =      -0.716;
       d =   -0.007226;
       y = a*exp(b*x) + c*exp(d*x);