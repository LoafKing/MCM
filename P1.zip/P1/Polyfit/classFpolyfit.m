plot(p3final(:,1),p3final(:,2),'.')
[p,s]=polyfit(p3final(:,1),p3final(:,2),5);
[y,delta]=polyconf(p,p3final(:,1),s);
polytool(p3final(:,1),p3final(:,2),5)
y=polyval(p,p3final(:,1));
a=p3final(:,1);
b=p3final(:,2);