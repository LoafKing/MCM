plot(hfinal(:,1),hfinal(:,2),'.')
[p,s]=polyfit(hfinal(:,1),hfinal(:,2),6);
[y,delta]=polyconf(p,hfinal(:,1),s);
polytool(hfinal(:,1),hfinal(:,2),6)
y=polyval(p,hfinal(:,1));
a=hfinal(:,1);
b=hfinal(:,2);