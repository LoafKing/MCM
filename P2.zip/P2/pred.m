function y = pred(x1,x2,x3)
y=3.7242+1.8140*x1+1.0387*x2+7.8475*x3;
