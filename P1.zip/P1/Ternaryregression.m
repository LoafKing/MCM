%% Ternary linear regression
%x1: extension rate ave
x1=ones(24,1);
for i=1:24
x1(i,1)= Exrateave(i);
end
% 10% Temperature random fluctuation
%fl=2*(rand(1,24)-0.5).*0.1;
%fl(1:8)=fl(1:8).*10;
%fl(9:16)=fl(9:16).*16;
%fl(17:24)=fl(17:24).*22;
%fl=fl';
%x2: temperature
a=10*ones(8,1)';
b=16*ones(8,1)';
c=22*ones(8,1)';
x2=[a,b,c]';x2=x2+fl;
%x3: moisture or water potential
moi=[-1.756;-1.093;-0.780;-1.592;-1.715;-1.160;-2.774;-1.60];
x3=[moi;moi;moi];
y=[Derateave(:,1);Derateave(:,2);Derateave(:,3);];
x=[ones(24,1),x1,x2,x3];
[b,bint,r,rint,stats]=regress(y,x);
b,bint,stats,figure,rcoplot(r,rint)
