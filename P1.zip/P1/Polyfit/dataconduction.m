p3final=(p+p1)./2;
p1final=(p2+p3)./2;
p2final=(p4+p5+p6+p7)./4;