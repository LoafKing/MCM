plot(p1final(:,1),p1final(:,2),'.')
[p,s]=polyfit(p1final(:,1),p1final(:,2),6);
[y,delta]=polyconf(p,p1final(:,1),s);
polytool(p1final(:,1),p1final(:,2),6)
y=polyval(p,p1final(:,1));
a=p1final(:,1);
b=p1final(:,2);