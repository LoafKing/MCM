%% Extreme 2 T=32.85 H=46.8=--1.1495
x2=[0.58,0.83,12.4,12.5,3.8,7.8,8.65,13.55];
x=x2./3.183;
rate1=[0.02,0.03,24,24,1,10.11,12.7,26.78];
s1=sum(rate1);
rate1=rate1./s1;
%% Normal 1 T=27.86 H=92.13=-0.3922
x1=[0.7,6.7,12.3,13.3,3.65,9.7,8.1,8.22];
Armi=[0.016];
Hyphode=[1];
Meru=[7.72];
Phlebio=[9.42];
Phelli=[0.13];
Phlebia=[3.90];
Sch=[2.09];
Others=[2.19];
rate2=[Armi,Hyphode,Meru,Phlebio,Phelli,Phlebia,Sch,Others];
s2=sum(rate2);
rate2=rate2./s2;
%% Plot
finalrate=[rate1;rate2];
bar3(finalrate);
zlabel('Population share')
set(gcf,'color',[1 1 1])
Xname={'Armi','Hyphode','Meru','Phlebio','Phelli','Phlebia','Sch','Others'};
set(gca,'XTickLabel',Xname);
Yname={'Normal','Extreme'};
set(gca,'YTickLabel',Yname);
%% Derate comparation
derate1=pred(x1,27.86,-0.3922);
derate2=pred(x2,32.85,-1.3981);
derate3=rate1.*derate1;
derate4=rate2.*derate2;
derateave1=sum(derate3);derateave2=sum(derate4);