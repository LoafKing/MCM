plot(afinal(:,1),afinal(:,2),'.')
[p,s]=polyfit(afinal(:,1),afinal(:,2),5);
[y,delta]=polyconf(p,afinal(:,1),s);
polytool(afinal(:,1),afinal(:,2),5)
y=polyval(p,afinal(:,1));
a=afinal(:,1);
b=afinal(:,2);