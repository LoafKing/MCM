% Models of 34 kinds of different mycelial extensive rate and decomposition rate
%% temperature = 10
derate10=derate(:,1)';
exrate10=exrate(:,1)';
derate16=derate(:,2)';
exrate16=exrate(:,2)';
derate22=derate(:,3)';
exrate22=exrate(:,3)';
figure, hold on
plot(exrate10,derate10,'.r')
plot(exrate16,derate16,'.m')
plot(exrate22,derate22,'.b')
legend('10℃','16℃','22℃')
xlabel('Hyphal extension rate (mm/day)','Fontsize',10)
ylabel('Decomposition rate (%)','Fontsize',10)
hold off
set(gcf,'color',[1 1 1])