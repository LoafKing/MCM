%% temperature = 10℃
for i=1:8
eval(['x',num2str(i),'=[0,Exrateave(',num2str(i),',1)];'])
eval(['y',num2str(i),'=[0,Derateave(',num2str(i),',1)];'])
end
for i=1:8
    hold on
eval(['plot(x',num2str(i),',y',num2str(i),',''linewidth'',1);'])
    end
hold off
legend('Armillaria','Hyphoderma','Merulius','Phlebiopsis','Phellinus','Phlebia','Schizophyllum','Others')
xlabel('Hyphal extension (mm/day)','Fontsize',10)
ylabel('Decomposition rate (%)','Fontsize',10)
title('Temperature = 10℃')
set(gcf,'color',[1 1 1])

%% temperature = 16℃
%for i=1:8
%eval(['x',num2str(i),'=[0,Exrateave(',num2str(i),',2)];'])
%eval(['y',num2str(i),'=[0,Derateave(',num2str(i),',2)];'])
%end
%for i=1:8
%    hold on
%eval(['plot(x',num2str(i),',y',num2str(i),',''linewidth'',1);'])
%  end
%hold off
%legend('Armillaria','Hyphoderma','Merulius','Phlebiopsis','Phellinus','Phlebia','Schizophyllum','Others')
%xlabel('Hyphal extension (mm/day)','Fontsize',10)
%ylabel('Decomposition rate (%)','Fontsize',10)
%title('Temperature = 16℃')
%set(gcf,'color',[1 1 1])