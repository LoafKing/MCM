function y = pred(x1,x2,x3)
y=1.7800+1.9857*x1+1.1991*x2+8.6785*x3;
