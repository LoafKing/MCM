plot(sfinal(:,1),sfinal(:,2),'.')
[p,s]=polyfit(sfinal(:,1),sfinal(:,2),10);
[y,delta]=polyconf(p,sfinal(:,1),s);
polytool(sfinal(:,1),sfinal(:,2),10)
y=polyval(p,sfinal(:,1));
a=sfinal(:,1);
b=sfinal(:,2);