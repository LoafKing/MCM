plot(other(:,1),other(:,2),'.')
[p,s]=polyfit(other(:,1),other(:,2),6);
[y,delta]=polyconf(p,other(:,1),s);
polytool(other(:,1),other(:,2),6)
y=polyval(p,other(:,1));
a=other(:,1);
b=other(:,2);