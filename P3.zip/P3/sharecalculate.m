Armi=[0.016];
Hyphode=[1];
Meru=[7.72];
Phlebio=[9.42];
Phelli=[0.13];
Phlebia=[3.90];
Sch=[2.09];
Others=[2.19];
x=[Hyphode,Meru,Phlebio,Phelli,Phlebia,Sch,Others];
figure
pie(x);
legend('Hyphoderma','Merulius','Phlebiopsis','Phellinus','Phlebia','Schizophyllum','Others')
set(gcf,'color',[1 1 1])