%% Binary linear regression 3x
%x1:extension rate ave
x1=[Exrateave(:,1);Exrateave(:,2);Exrateave(:,3);];
%x2:temperature
a=10*ones(8,1)';
b=16*ones(8,1)';
c=22*ones(8,1)';
x2=[a,b,c]';
%x3:moisture/water potential

y=[Derateave(:,1);Derateave(:,2);Derateave(:,3);];
x=[ones(24,1),x1,x2,x3];
[b,bint,r,rint,stats]=regress(y,x);
b,bint,stats,figure,rcoplot(r,rint)
