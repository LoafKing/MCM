plot(mfinal(:,1),mfinal(:,2),'.')
[p,s]=polyfit(mfinal(:,1),mfinal(:,2),9);
[y,delta]=polyconf(p,mfinal(:,1),s);
polytool(mfinal(:,1),mfinal(:,2),9)
y=polyval(p,mfinal(:,1));
a=mfinal(:,1);
b=mfinal(:,2);